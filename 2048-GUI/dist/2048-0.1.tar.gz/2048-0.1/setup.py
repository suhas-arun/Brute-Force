from distutils.core import setup

setup(
    name='2048',
    version='0.1',
    packages=['2048',],
    long_description="2048 game made in Python with tkinter",
)