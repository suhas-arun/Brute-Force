from distutils.core import setup

setup(
    name='Codeforces-Scraper',
    version='0.1',
    packages=['Codeforces-Scraper',],
    long_description="Codeforces scraper using the Codeforces API to return user info.",
)