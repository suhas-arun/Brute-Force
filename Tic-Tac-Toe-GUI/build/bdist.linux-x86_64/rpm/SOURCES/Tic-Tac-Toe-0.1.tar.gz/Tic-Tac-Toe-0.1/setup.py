from distutils.core import setup

setup(
    name='Tic-Tac-Toe',
    version='0.1',
    packages=['Tic-Tac-Toe',],
    long_description="Tic Tac Toe (aka Noughts and Crosses) made in Python with tkinter",
)